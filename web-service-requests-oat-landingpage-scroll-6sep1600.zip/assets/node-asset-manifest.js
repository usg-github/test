/* eslint-disable */
define('rdc-ui-app-spv2/config/node-asset-manifest', function() {
  return {
    default: {"bundles":{"rdc-ui-eng-service-requests":{"assets":[{"uri":"/retail/service-requests/engines-dist/rdc-ui-eng-service-requests/assets/engine-100bddde5b0da418dd1622638f40cd3b.js","type":"js"},{"uri":"/retail/service-requests/engines-dist/rdc-ui-eng-service-requests/assets/engine-3344c2d4e678e581606fb80b398ea6e7.css","type":"css"},{"uri":"/retail/service-requests/engines-dist/rdc-ui-eng-service-requests/assets/engine-vendor-2c1478595b5fae0eea90d92748a47805.js","type":"js"},{"uri":"/retail/service-requests/engines-dist/rdc-ui-eng-service-requests/config/environment-a64426d9979ccb3ea692cd20d55db66c.js","type":"js"}]}}}
  };
});
