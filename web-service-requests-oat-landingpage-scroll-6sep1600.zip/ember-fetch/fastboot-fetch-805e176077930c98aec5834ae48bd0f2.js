define("fetch",["exports"],function(e){var t=FastBoot.require("node-fetch")
e.default=t,e.Headers=t.Headers,e.Request=t.Request,e.Response=t.Response}),define("fetch/ajax",["exports"],function(){throw new Error("You included `fetch/ajax` but it was renamed to `ember-fetch/ajax`")})
